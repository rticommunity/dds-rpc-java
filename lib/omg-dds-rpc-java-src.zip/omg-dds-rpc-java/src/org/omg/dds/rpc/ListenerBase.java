package org.omg.dds.rpc;

public interface ListenerBase {

}
