package org.omg.dds.rpc;

import org.omg.dds.rpc.ReplierListener;
import org.omg.dds.rpc.SimpleReplierListener;
import org.omg.dds.domain.DomainParticipant;
import org.omg.dds.sub.Subscriber;
import org.omg.dds.sub.DataReaderQos;
import org.omg.dds.pub.Publisher;
import org.omg.dds.pub.DataWriterQos;

public interface ReplierParams {
	
    public <TReq, TRep> ReplierParams simpleReplierListener (
        SimpleReplierListener<TReq, TRep> listener);

    public <TReq, TRep> ReplierParams replierListener (
        ReplierListener<TReq, TRep> listener);

    public ReplierParams domain_participant(DomainParticipant participant);
    public ReplierParams serviceName (String name);
    public ReplierParams instanceName (String name);
    public ReplierParams requestTopicName (String name);
    public ReplierParams replyTopicName (String name);
    public ReplierParams dataWriterQos (DataWriterQos qos);
    public ReplierParams dataReaderQos (DataReaderQos qos);
    public ReplierParams publisher (Publisher publisher);
    public ReplierParams subscriber (Subscriber subscriber);

    public DomainParticipant domainParticipant();
    public ListenerBase simpleRequesterListener();
    public ListenerBase requesterListener();
    public String serviceName();
    public String instanceName(); 
    public String requestTopicName();
    public String replyTopicName();
    public DataWriterQos dataWriterQos();
    public DataReaderQos dataReaderQos();
    public Publisher publisher();
    public Subscriber subscriber();

}
