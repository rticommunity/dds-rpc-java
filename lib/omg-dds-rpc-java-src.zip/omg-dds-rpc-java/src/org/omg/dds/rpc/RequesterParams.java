package org.omg.dds.rpc;

import org.omg.dds.rpc.RequesterListener;
import org.omg.dds.rpc.SimpleRequesterListener;
import org.omg.dds.domain.DomainParticipant;
import org.omg.dds.sub.Subscriber;
import org.omg.dds.sub.DataReaderQos;
import org.omg.dds.pub.Publisher;
import org.omg.dds.pub.DataWriterQos;

public interface RequesterParams {
	
    public <TRep> RequesterParams simpleRequesterListener (
        SimpleRequesterListener<TRep> listener);

    public <TReq, TRep> RequesterParams requesterListener (
        RequesterListener<TReq, TRep> listener);

    public RequesterParams domain_participant(DomainParticipant participant);
    public RequesterParams serviceName (String name);
    public RequesterParams requestTopicName (String name);
    public RequesterParams replyTopicName (String name);
    public RequesterParams dataWriterQos (DataWriterQos qos);
    public RequesterParams dataReaderQos (DataReaderQos qos);
    public RequesterParams publisher (Publisher publisher);
    public RequesterParams subscriber (Subscriber subscriber);

    public DomainParticipant domainParticipant();
    public ListenerBase simpleRequesterListener();
    public ListenerBase requesterListener();
    public String serviceName();
    public String requestTopicName();
    public String replyTopicName();
    public DataWriterQos dataWriterQos();
    public DataReaderQos dataReaderQos();
    public Publisher publisher();
    public Subscriber subscriber();

}
